-- ==========================================
-- Phase 3 SQL Schema - Store Management System
-- ==========================================

-- -----------------------------------------
-- 1. Create the 'stores' table for storing store details
-- -----------------------------------------
CREATE TABLE stores (
    store_id INT AUTO_INCREMENT PRIMARY KEY,
    store_name VARCHAR(255) NOT NULL,
    store_location VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- -----------------------------------------
-- 2. Create the 'stock' table for managing product inventory levels per store
-- -----------------------------------------
CREATE TABLE stock (
    stock_id INT AUTO_INCREMENT PRIMARY KEY,
    store_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(store_id) ON DELETE CASCADE
);

-- -----------------------------------------
-- 3. Create the 'orders' table for storing customer orders
-- -----------------------------------------
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    store_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    customer_id INT NOT NULL,
    order_status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(store_id),
    FOREIGN KEY (product_id) REFERENCES stock(product_id)
);

-- -----------------------------------------
-- 4. Create the 'audit_logs' table for tracking significant operations
-- -----------------------------------------
CREATE TABLE audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    store_id INT NOT NULL,
    action VARCHAR(255) NOT NULL,
    details TEXT,
    performed_by INT,  -- Can reference an admin or system user
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(store_id)
);

-- -----------------------------------------
-- 5. Create the 'store_replicas' table for read replica setup
-- -----------------------------------------
CREATE TABLE store_replicas (
    replica_id INT AUTO_INCREMENT PRIMARY KEY,
    store_id INT NOT NULL,
    replica_address VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (store_id) REFERENCES stores(store_id)
);

-- ==========================================
-- Indexes and Constraints for optimization
-- ==========================================
CREATE INDEX idx_store_id ON stock (store_id);
CREATE INDEX idx_product_id ON stock (product_id);
CREATE INDEX idx_order_status ON orders (order_status);
CREATE INDEX idx_audit_timestamp ON audit_logs (timestamp);

-- ==========================================
-- Example Query to Get Store Inventory
-- ==========================================
-- This query will be used by the application to fetch current stock for a store.
SELECT s.store_name, st.product_id, st.quantity 
FROM stores s
JOIN stock st ON s.store_id = st.store_id
WHERE s.store_id = 1;

-- ==========================================
-- Example Query to Place an Order
-- ==========================================
-- This query simulates placing an order and updating the stock quantity.
-- Assuming an order is being placed for product_id 1 in store_id 1.

-- Step 1: Insert the order
INSERT INTO orders (store_id, product_id, quantity, customer_id, order_status)
VALUES (1, 1, 2, 101, 'pending');

-- Step 2: Update the stock after the order
UPDATE stock 
SET quantity = quantity - 2
WHERE store_id = 1 AND product_id = 1;

-- Step 3: Insert an audit log entry for stock update
INSERT INTO audit_logs (store_id, action, details, performed_by)
VALUES (1, 'Stock Update', 'Decreased 2 units of product_id 1', 1);

-- ==========================================
-- Setup Read Replicas (for scalability)
-- ==========================================
-- You should set up MySQL read replicas in your production environment.
-- This can be done using replication features, but that's handled outside of the schema.
-- A simple query can track the replicas in the 'store_replicas' table.

SELECT * FROM store_replicas WHERE is_active = TRUE;
