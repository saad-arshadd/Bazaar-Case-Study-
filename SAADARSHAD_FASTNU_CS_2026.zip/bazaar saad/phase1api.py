from fastapi import FastAPI
from pydantic import BaseModel
import sqlite3
from typing import List
from datetime import datetime, timedelta

app = FastAPI()

# Helper function to get a DB connection
def get_db_connection():
    conn = sqlite3.connect('inventory.db')
    conn.row_factory = sqlite3.Row
    return conn

# Define data models
class Product(BaseModel):
    name: str
    quantity: int

class StockMovement(BaseModel):
    product_id: int
    action: str  # "stock-in", "sell", "remove"
    quantity: int

# 1. Add a product to inventory
@app.post("/products/")
def add_product(product: Product):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO products (name, quantity) VALUES (?, ?)",
                   (product.name, product.quantity))
    conn.commit()
    conn.close()
    return {"message": "Product added successfully"}

# 2. Add stock movement (stock-in, sell, or remove)
@app.post("/stock_movements/")
def add_stock_movement(movement: StockMovement):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO stock_movements (product_id, action, quantity) VALUES (?, ?, ?)",
                   (movement.product_id, movement.action, movement.quantity))
    conn.commit()

    # Update product quantity based on the action
    if movement.action == "stock-in":
        cursor.execute("UPDATE products SET quantity = quantity + ? WHERE id = ?",
                       (movement.quantity, movement.product_id))
    elif movement.action in ["sell", "remove"]:
        cursor.execute("UPDATE products SET quantity = quantity - ? WHERE id = ?",
                       (movement.quantity, movement.product_id))

    conn.commit()
    conn.close()
    return {"message": "Stock movement recorded successfully"}

# 3. View current stock
@app.get("/products/")
def get_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()
    conn.close()
    return {"products": [dict(product) for product in products]}

# 4. View low stock products + restocking suggestions
@app.get("/low_stock/")
def low_stock_suggestions():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Step 1: Fetch products with quantity < 10
    cursor.execute("SELECT id, name, quantity FROM products WHERE quantity < 10")
    low_stock = cursor.fetchall()

    result = []
    one_week_ago = (datetime.now() - timedelta(days=7)).isoformat()

    for product in low_stock:
        product_id = product["id"]
        product_name = product["name"]
        product_quantity = product["quantity"]

        # Step 2: Count "sell" stock movements in last 7 days
        cursor.execute("""
            SELECT COUNT(*) FROM stock_movements 
            WHERE product_id = ? AND action = 'sell' AND date > ?
        """, (product_id, one_week_ago))
        sell_count = cursor.fetchone()[0]

        restock_needed = "Yes" if sell_count > 5 else "No"

        result.append({
            "product_id": product_id,
            "name": product_name,
            "quantity": product_quantity,
            "recent_sales": sell_count,
            "restock_recommended": restock_needed
        })

    conn.close()
    return {"low_stock_suggestions": result}

# Initialize database schema
def init_db():
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        quantity INTEGER NOT NULL
    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS stock_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        action TEXT,
        quantity INTEGER,
        date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products (id)
    )''')

    conn.commit()
    conn.close()

# Initialize the database (if not already done)
init_db()
