from fastapi import FastAPI
from pydantic import BaseModel
import sqlite3
from datetime import datetime, timedelta
from typing import Optional, List

app = FastAPI()

# --------------------------- DATABASE INIT ---------------------------

def init_db():
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        sku TEXT NOT NULL,
        quantity INTEGER NOT NULL
    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS stock_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        movement_type TEXT,
        quantity INTEGER,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products (id)
    )''')

    conn.commit()
    conn.close()

init_db()

# --------------------------- MODELS ---------------------------

class Product(BaseModel):
    name: str
    sku: str
    quantity: int

class StockMovement(BaseModel):
    product_id: int
    movement_type: str  # 'stock_in', 'sale', or 'manual_removal'
    quantity: int

# --------------------------- ROUTES ---------------------------

@app.post("/add_product/")
def add_product(product: Product):
    conn = sqlite3.connect("inventory.db")
    cursor = conn.cursor()

    cursor.execute("INSERT INTO products (name, sku, quantity) VALUES (?, ?, ?)",
                   (product.name, product.sku, product.quantity))
    conn.commit()
    conn.close()
    return {"message": "Product added successfully"}

@app.post("/move_stock/")
def move_stock(movement: StockMovement):
    conn = sqlite3.connect("inventory.db")
    cursor = conn.cursor()

    # Get current product quantity
    cursor.execute("SELECT quantity FROM products WHERE id = ?", (movement.product_id,))
    row = cursor.fetchone()

    if not row:
        return {"error": "Product not found"}
    
    current_qty = row[0]

    if movement.movement_type == 'stock_in':
        new_qty = current_qty + movement.quantity
    elif movement.movement_type in ['sale', 'manual_removal']:
        if movement.quantity > current_qty:
            return {"error": "Insufficient stock"}
        new_qty = current_qty - movement.quantity
    else:
        return {"error": "Invalid movement_type"}

    # Update quantity
    cursor.execute("UPDATE products SET quantity = ? WHERE id = ?", (new_qty, movement.product_id))

    # Record movement
    cursor.execute("INSERT INTO stock_movements (product_id, movement_type, quantity) VALUES (?, ?, ?)",
                   (movement.product_id, movement.movement_type, movement.quantity))

    conn.commit()
    conn.close()
    return {"message": "Stock movement recorded"}

@app.get("/low_stock/")
def get_low_stock_suggestions():
    conn = sqlite3.connect("inventory.db")
    cursor = conn.cursor()

    cursor.execute("SELECT id, name, sku, quantity FROM products WHERE quantity < 10")
    low_stock_products = cursor.fetchall()

    suggestions = []
    one_week_ago = (datetime.now() - timedelta(days=7)).isoformat()

    for prod in low_stock_products:
        prod_id, name, sku, qty = prod

        # Count sales in last 7 days
        cursor.execute(""" 
            SELECT SUM(quantity) FROM stock_movements
            WHERE product_id = ? AND movement_type = 'sale' AND timestamp > ?
        """, (prod_id, one_week_ago))

        sales_count = cursor.fetchone()[0]
        sales_count = sales_count if sales_count else 0

        restock = sales_count > 5

        suggestions.append({
            "product_id": prod_id,
            "name": name,
            "sku": sku,
            "current_quantity": qty,
            "sales_last_7_days": sales_count,
            "restock_recommended": restock
        })

    conn.close()
    return {"low_stock_suggestions": suggestions}
