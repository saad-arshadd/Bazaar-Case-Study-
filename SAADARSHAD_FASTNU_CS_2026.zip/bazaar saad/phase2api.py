from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel
import psycopg2
from psycopg2.extras import RealDictCursor
from typing import List
from datetime import datetime, timedelta
from fastapi_limiter import FastAPILimiter
from fastapi_limiter.depends import RateLimiter
import aioredis


app = FastAPI()


# Initialize PostgreSQL connection
def get_db_connection():
    conn = psycopg2.connect(
        dbname="inventory_db", 
        user="your_user", 
        password="your_password", 
        host="localhost", 
        port="5432"
    )
    conn.autocommit = True
    return conn

# Define data models
class Product(BaseModel):
    name: str
    description: str = None

class Store(BaseModel):
    name: str
    location: str

class StockMovement(BaseModel):
    store_id: int
    product_id: int
    action: str  # "stock-in", "sell", "remove"
    quantity: int

class StoreProduct(BaseModel):
    store_id: int
    product_id: int
    quantity: int

# Helper function for checking authentication
def verify_credentials(credentials: HTTPBasicCredentials = Depends(security)):
    correct_username = "admin"
    correct_password = "password"
    if credentials.username != correct_username or credentials.password != correct_password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect credentials",
            headers={"WWW-Authenticate": "Basic"},
        )

# Rate limit using FastAPI Limiter
@app.on_event("startup")
async def startup():
    redis = await aioredis.create_redis_pool("redis://localhost:6379")
    FastAPILimiter.init(redis)

# 1. Add a store
@app.post("/stores/")
async def add_store(store: Store, credentials: HTTPBasicCredentials = Depends(verify_credentials)):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO stores (name, location) VALUES (%s, %s) RETURNING id",
                   (store.name, store.location))
    store_id = cursor.fetchone()[0]
    conn.close()
    return {"store_id": store_id}

# 2. Add a product to the central catalog
@app.post("/products/")
async def add_product(product: Product, credentials: HTTPBasicCredentials = Depends(verify_credentials)):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO products (name, description) VALUES (%s, %s) RETURNING id",
                   (product.name, product.description))
    product_id = cursor.fetchone()[0]
    conn.close()
    return {"product_id": product_id}

# 3. Add or update store-specific stock
@app.post("/store_products/")
async def add_or_update_store_product(store_product: StoreProduct, credentials: HTTPBasicCredentials = Depends(verify_credentials)):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO store_products (store_id, product_id, quantity)
        VALUES (%s, %s, %s)
        ON CONFLICT (store_id, product_id)
        DO UPDATE SET quantity = store_products.quantity + %s
        RETURNING id
    """, (store_product.store_id, store_product.product_id, store_product.quantity, store_product.quantity))
    conn.close()
    return {"message": "Store product stock updated successfully"}

# 4. Record a stock movement (stock-in, sell, or remove)
@app.post("/stock_movements/")
async def add_stock_movement(movement: StockMovement, credentials: HTTPBasicCredentials = Depends(verify_credentials)):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO stock_movements (store_id, product_id, action, quantity)
        VALUES (%s, %s, %s, %s)
        RETURNING id
    """, (movement.store_id, movement.product_id, movement.action, movement.quantity))
    conn.commit()

    # Update store product quantity based on the action
    if movement.action == "stock-in":
        cursor.execute("""
            UPDATE store_products SET quantity = quantity + %s
            WHERE store_id = %s AND product_id = %s
        """, (movement.quantity, movement.store_id, movement.product_id))
    elif movement.action in ["sell", "remove"]:
        cursor.execute("""
            UPDATE store_products SET quantity = quantity - %s
            WHERE store_id = %s AND product_id = %s
        """, (movement.quantity, movement.store_id, movement.product_id))

    conn.commit()
    conn.close()
    return {"message": "Stock movement recorded successfully"}

# 5. View stock by store
@app.get("/store/{store_id}/stock/")
async def view_store_stock(store_id: int, credentials: HTTPBasicCredentials = Depends(verify_credentials)):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT p.name, sp.quantity 
        FROM store_products sp
        JOIN products p ON sp.product_id = p.id
        WHERE sp.store_id = %s
    """, (store_id,))
    store_stock = cursor.fetchall()
    conn.close()
    return {"store_stock": store_stock}

# 6. Filter stock movements by date range
@app.get("/stock_movements/filter/")
async def filter_stock_movements(start_date: str, end_date: str, credentials: HTTPBasicCredentials = Depends(verify_credentials)):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT sm.date, sm.action, sm.quantity, p.name 
        FROM stock_movements sm
        JOIN products p ON sm.product_id = p.id
        WHERE sm.date BETWEEN %s AND %s
    """, (start_date, end_date))
    stock_movements = cursor.fetchall()
    conn.close()
    return {"stock_movements": stock_movements}
