from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from sqlalchemy import create_engine, Column, Integer, String, TIMESTAMP, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import redis
import aioredis
import json
from datetime import datetime
from kafka import KafkaProducer

# Create FastAPI app
app = FastAPI()

# Database configuration
DATABASE_URL = "mysql+mysqlconnector://user:password@localhost/dbname"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Redis client for caching
redis_client = redis.StrictRedis(host='localhost', port=6379, db=0)

# Kafka producer for event-driven updates
producer = KafkaProducer(bootstrap_servers='localhost:9092')

# Models (SQLAlchemy)
class Store(Base):
    __tablename__ = 'stores'
    store_id = Column(Integer, primary_key=True, index=True)
    store_name = Column(String, index=True)
    store_location = Column(String)

class Stock(Base):
    __tablename__ = 'stock'
    stock_id = Column(Integer, primary_key=True, index=True)
    store_id = Column(Integer, ForeignKey("stores.store_id"))
    product_id = Column(Integer)
    quantity = Column(Integer)
    last_updated = Column(TIMESTAMP, default=datetime.utcnow)

# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Helper function for sending events (e.g., stock update)
def send_event(event_data):
    producer.send('stock-updates', json.dumps(event_data).encode('utf-8'))

@app.post("/update-stock/{store_id}/{product_id}")
async def update_stock(store_id: int, product_id: int, quantity: int, background_tasks: BackgroundTasks, db: SessionLocal = Depends(get_db)):
    # Check if store exists
    store = db.query(Store).filter(Store.store_id == store_id).first()
    if not store:
        raise HTTPException(status_code=404, detail="Store not found")
    
    # Update the stock in the database
    stock = db.query(Stock).filter(Stock.store_id == store_id, Stock.product_id == product_id).first()
    if stock:
        stock.quantity = quantity
        stock.last_updated = datetime.utcnow()
    else:
        new_stock = Stock(store_id=store_id, product_id=product_id, quantity=quantity)
        db.add(new_stock)
    
    db.commit()
    db.refresh(stock)

    # Send asynchronous event to Kafka for stock update
    event_data = {
        "store_id": store_id,
        "product_id": product_id,
        "quantity": quantity,
        "timestamp": datetime.utcnow().isoformat()
    }
    background_tasks.add_task(send_event, event_data)

    # Cache update in Redis
    redis_client.set(f"stock:{store_id}:{product_id}", quantity)

    return {"message": "Stock updated successfully"}

@app.get("/get-stock/{store_id}/{product_id}")
async def get_stock(store_id: int, product_id: int):
    # Check the cache first
    cached_stock = redis_client.get(f"stock:{store_id}:{product_id}")
    if cached_stock:
        return {"store_id": store_id, "product_id": product_id, "quantity": int(cached_stock)}

    # If not in cache, get it from the database
    db = SessionLocal()
    stock = db.query(Stock).filter(Stock.store_id == store_id, Stock.product_id == product_id).first()
    if stock:
        return {"store_id": store_id, "product_id": product_id, "quantity": stock.quantity}

    raise HTTPException(status_code=404, detail="Stock not found")

@app.get("/audit-logs")
async def get_audit_logs(db: SessionLocal = Depends(get_db)):
    # Retrieve all audit logs (just an example)
    logs = db.execute("SELECT * FROM audit_logs ORDER BY timestamp DESC").fetchall()
    return {"logs": logs}
