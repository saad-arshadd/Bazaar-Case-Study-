from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import aiomysql
import asyncio

router = APIRouter()

# Connection pool setup
pool = None

class StockUpdate(BaseModel):
    store_id: int
    item_id: int
    quantity: int
    timestamp: str

@router.on_event("startup")
async def startup():
    global pool
    pool = await aiomysql.create_pool(
        host='localhost',
        port=3306,
        user='root',
        password='password',
        db='bazaar',
        autocommit=True
    )

@router.post("/update_stock/")
async def update_stock(data: StockUpdate):
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute("""
                INSERT INTO stock (store_id, item_id, quantity, timestamp)
                VALUES (%s, %s, %s, %s)
            """, (data.store_id, data.item_id, data.quantity, data.timestamp))
    return {"status": "success"}

@router.get("/get_stock/{item_id}")
async def get_stock(item_id: int):
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute("SELECT * FROM stock WHERE item_id = %s", (item_id,))
            result = await cur.fetchall()
    return result
