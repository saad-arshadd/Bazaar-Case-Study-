import asyncio
import json
import aioredis

async def handle_stock_update(message):
    data = json.loads(message)
    print(f"Received update: {data}")
    # You can update the database here or trigger downstream actions.

async def subscribe_to_updates():
    redis = await aioredis.create_redis("redis://localhost:6379")
    res = await redis.subscribe("stock_updates")
    ch1 = res[0]

    async for msg in ch1.iter(encoding="utf-8"):
        await handle_stock_update(msg)

if __name__ == "__main__":
    asyncio.run(subscribe_to_updates())
