# Distributed Stock Management System – Case Study

This document outlines the design, evolution, and implementation considerations for a horizontally scalable, distributed stock management system that supports real-time stock synchronization, audit logging, and robust asynchronous communication using modern web technologies.

---

## 📌 Overview

The system supports:
- Thousands of retail stores across regions.
- Real-time stock updates with eventual consistency.
- Fast read operations through caching (Redis).
- Event-driven architecture via Kafka.
- Audit trails of all stock transactions.
- Read/Write separation and API rate-limiting for scalability.

---

## 🔧 Design Decisions

| Component            | Decision                                                                 |
|---------------------|--------------------------------------------------------------------------|
| **API Framework**   | FastAPI for async support and modern API development                     |
| **Database**        | MySQL with future support for read-replica (for R/W separation)          |
| **Caching**         | Redis for quick access to frequently requested stock values              |
| **Messaging**       | Kafka used to broadcast stock updates asynchronously                     |
| **Async Processing**| FastAPI `BackgroundTasks` and Kafka consumers used for async operations  |
| **Audit Logging**   | A separate `audit_logs` table is used for compliance and monitoring      |
| **Rate Limiting**   | SlowAPI used to throttle high-frequency reads                            |
| **Scalability**     | Designed to be horizontally scalable using stateless APIs, caching, etc. |

---

## 📎 Assumptions

- Each store is uniquely identified by `store_id`.
- Products are identified by `product_id`; no dedicated product metadata table.
- Kafka, Redis, and MySQL are running locally on default ports.
- Write and Read DB separation is conceptual and prepared for deployment-level scaling.
- Audit logs are stored for compliance, not queried frequently.
- Security and auth are outside the current implementation scope.

---

## 📐 API Design

### 1. `POST /update-stock/{store_id}/{product_id}?quantity=`
- Updates stock of a product for a given store.
- Stores changes in the DB and Redis cache.
- Sends update event to Kafka and stores an audit log.

### 2. `GET /get-stock/{store_id}/{product_id}`
- Retrieves stock quantity using cache-first logic.
- If not cached, fetches from DB and updates Redis.
- Rate limited to 5 requests/second per IP.

### 3. `GET /audit-logs`
- Returns complete history of stock updates from `audit_logs` table.

---

## 🔁 Evolution Rationale (Phase 1 → Phase 3)

### Phase 1 – MVP (Minimum Viable Product)
- Developed a basic RESTful API using FastAPI and MySQL.
- Simple stock update and retrieval endpoints.
- Direct DB access without optimization or async features.

### Phase 2 – Performance Optimization
- Introduced Redis for caching to improve response time and reduce DB load.
- Applied FastAPI `BackgroundTasks` for non-blocking processing.
- Introduced abstraction for potential Read/Write DB separation.

### Phase 3 – Production-Ready System
- Integrated Kafka for asynchronous, decoupled, and scalable event processing.
- Added audit logging for accountability and data integrity.
- Applied API rate limiting to prevent abuse and ensure fair access.
- Achieved full horizontal scalability: stateless API, Redis, Kafka-based workflows.
- Ensured readiness to support thousands of concurrent store operations.

---

## 🧱 Project Structure

