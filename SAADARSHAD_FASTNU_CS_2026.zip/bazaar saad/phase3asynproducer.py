import asyncio
import json
import aioredis

async def publish_update():
    redis = await aioredis.create_redis_pool("redis://localhost:6379")
    stock_update = {
        "store_id": 1,
        "item_id": 101,
        "quantity": 15,
        "timestamp": "2025-04-14T12:34:56"
    }
    await redis.publish_json("stock_updates", stock_update)
    print("Published:", stock_update)
    redis.close()
    await redis.wait_closed()

if __name__ == "__main__":
    asyncio.run(publish_update())
